# coding: utf8
import os 
import subprocess

## import option parser
from optparse import OptionParser

## import sys
import sys

import time

## import ALProxy to connect to Naoqi on the robot
from naoqi import ALProxy

## import numpy for matrix operations and OpenCV
import numpy as np

## import OpenCV for visualization
import cv2

## import NAO vision definitions for image grabbing
from vision_definitions import kVGA, kBGRColorSpace

from naoqi import ALProxy 

IP = "/*ADRESSE IP*/"
tts = ALProxy("ALTextToSpeech", IP, 9559)
memory = ALProxy("ALMemory", IP, 9559)

tts.say ('Si tu veux jouer au Tic Tac Tou touche ma main gauche, si tu veux jouer au Mastermaïnd touche ma main droite et si tu veux quitter le jeu touche ma tête')

toucher = 1 
fin = 1 
while toucher != 0 : 
            if memory.getData("HandRightBackTouched"):
		tts.say ('Mastermaïnd')
		tts.say ('Veux-tu que je t explique les rêgles Si oui rappuie sur ma main droite. Sinon appuie sur ma tête') 
		while fin != 0 :  
			if memory.getData("HandRightBackTouched"):
				fin = 0 
				tts.say ('Je vais vous expliquer quelques règles. Pour commencer la partie vous devez appuyer sur ma tête. Ensuite quand vous aurez constitué votre combinaison de 3 couleurs différentes (rose, jaune, orange, bleu, mauve) sur la ligne deuxième ligne du plateau de 3 fois 3 cases vous appuierez de nouveau sur ma tête et cette manipulation sera à effectuer pour chaque nouvelle combinaison afin que je lance la correction. Une fois qu une combinaison a été corrigée vous devez lenlever du plateau et la placer sur le plateau de 3 fois 10 afin de vous rappeler vos précédentes combinaisons. Vous pouvez également vous servir de lautre plateau de 3 fois 10 et des pions rouges et blancs afin de noter les corrections. ') 
				subprocess.call(["D:/Informatique/Python27/python.exe", "/*CHEMIN VERS MENU*/+ /menu/nao-mind-master/main_xo.py"])
				subprocess.call(["D:/Informatique/Python27/python.exe", "/*CHEMIN VERS MENU*/+ /menu/main_xo.py"])
				
			elif memory.getData("FrontTactilTouched"):
				fin = 0 
				subprocess.call(["D:/Informatique/Python27/python.exe", "/*CHEMIN VERS MENU*/+ /menu/nao-mind-master/main_xo.py"])
				subprocess.call(["D:/Informatique/Python27/python.exe", "/*CHEMIN VERS MENU*/+ /menu/main_xo.py"])
		
            elif memory.getData("HandLeftBackTouched"):
                tts.say('Tic Tac Tou')
		tts.say ('Veux-tu que je t explique les rêgles Si oui rappuie sur ma main gauche. Sinon appuie sur ma tête') 
		while fin != 0 :
			if memory.getData("HandLeftBackTouched"):
				fin = 0 
				tts.say ('Je vais vous expliquer quelques règles. Pour commencer une partie il vous suffit d’appuyer sur ma tête, si vous souhaitez commencer à jouer vous devez placer un pion rouge sur le plateau avant d appuyer sur ma tête et si vous voulez que je commence à jouer ne placez rien sur le plateau avant d appuyer sur ma tête. Il vous suffira ensuite de suivre les instructions durant la partie. Pour les numéros que je donne durant la partie le 1 est situé en bas à droite puis le 2 et le 3 sur la même ligne et chaque ligne recommence à droite le 4 se situe donc au-dessus du 1.') 
				subprocess.call(["D:/Informatique/Python27/python.exe", "/*CHEMIN VERS MENU*/+ /menu/nao-xo-master/main_xo.py"])
				subprocess.call(["D:/Informatique/Python27/python.exe", "/*CHEMIN VERS MENU*/+ /menu/main_xo.py"])
			elif memory.getData("FrontTactilTouched"): 
				fin = 0 
				subprocess.call(["D:/Informatique/Python27/python.exe", "/*CHEMIN VERS MENU*/+ /menu/nao-xo-master/main_xo.py"])
				subprocess.call(["D:/Informatique/Python27/python.exe", "/*CHEMIN VERS MENU*/+ /menu/main_xo.py"])
				
            elif memory.getData("FrontTactilTouched"): 
		toucher = 0 
		break 
	    