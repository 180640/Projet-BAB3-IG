def pobjeda (ploca, combi, compteur):
    resultat="pas fini"
    compt = 0
    for j in range(3):
        if ploca[1][j]== combi[j]:
            compt+=1
    if (compt == 3):
        resultat="gagne"
    elif (compteur >= 10):
        resultat = "time out"
    print('resultat')
    print ('compteur =' + str(compteur)) 
    return resultat