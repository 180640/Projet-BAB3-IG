# coding: utf8
def verif(combi, combi_utilisateur):
    print ('combi utilisateur') 
    print(combi_utilisateur)
    ok = 0
    mp = 0
    for i in range(3):
        if (combi[i] == combi_utilisateur[1][i]):
            ok += 1
        elif (combi_utilisateur[1][i] in combi):
            mp += 1
	
    if (ok == 1) :
	ok = 'une'
    elif (mp == 1):
	mp = 'une'
    phrase1 = "Il y a" + str(ok) + " couleurs bien placées "
    phrase2 = "Il y a" + str(mp) + " couleurs présentes dans la combinaison et mal placées"
    return phrase1, phrase2 