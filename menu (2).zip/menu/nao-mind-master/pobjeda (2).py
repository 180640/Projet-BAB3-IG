#Déterminer le vainqueur en Krizic-krizic
def pobjeda (ploca,combi):
    
    rezultat="nerjeseno"
#LIGNES
    brojx=0
    brojo=0
    for j in range(3):
        if ploca[1][j]==combi[j]:
            brojx=brojx+1
    brojp=3-brojx-brojo
    if (brojp>0) and (rezultat=="nerjeseno"):
        rezultat="igra traje"
    elif brojx==3:
        rezultat="pobjeda x"
    elif brojo==3:
        rezultat="pobjeda o"
   # print("brojx u redcima je "+str(brojx))
   # print("brojo u redcima je "+str(brojo))
   # print("brojp u redcima je "+str(brojp))
return rezultat
